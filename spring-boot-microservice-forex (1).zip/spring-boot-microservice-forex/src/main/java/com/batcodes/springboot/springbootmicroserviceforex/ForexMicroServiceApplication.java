package com.batcodes.springboot.springbootmicroserviceforex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForexMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForexMicroServiceApplication.class, args);
	}
}
